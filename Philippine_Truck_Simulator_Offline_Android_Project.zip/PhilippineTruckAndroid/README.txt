PHILIPPINE TRUCK SIMULATOR — OFFLINE ANDROID PROJECT

This project contains an offline HTML/canvas truck-driving prototype packaged inside a simple Android WebView app. It does not load external libraries or need internet while playing.

Important: This is project source, not a compiled APK. The current environment does not have Android SDK/Gradle installed, so an APK cannot be built here directly.

To build an APK, use Android Studio on a computer or a trusted cloud Android build environment. Open this project as a Gradle project, build the debug APK, then install the generated app-debug.apk on Android. The GitHub Actions workflow in .github/workflows/android.yml can build it after the project is uploaded to a GitHub repository.

Prototype limitations: simple 2D perspective/canvas gameplay, not a full 3D game; generic truck artwork, not official Isuzu/J&T assets. No internet permission is requested by the app.
